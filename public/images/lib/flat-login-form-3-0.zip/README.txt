A Pen created at CodePen.io. You can find this one at http://codepen.io/andytran/pen/PwoQgO.

 Flat Login Form version 3.0.
Everything has been converted to Jade & SCSS.
A lot of properties have been removed, as well as unneeded prefixes.

Update Log
--
Created Nov. 14, 2014
--
Updated Apr. 30th, 2015
Just fixing up the old login form for a project I'm working on.
--
Updated Jul. 18th, 2015