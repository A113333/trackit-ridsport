Thank you for downloading from Tempees.com

Enjoy your free recourse.
We hope it will serve and facilitate your work.

WWW.TEMPEES.COM
cool free and premium templates and pictures
---------------------------

TWITTER: @tempeescom

FACEBOOK: https://www.facebook.com/tempeescom

---------------------------

LICENCE:
All our Free or Premium stuff you can use where you want.
For private and commercial purposes. 

Except re-selling or re-distributing. Please don't do this :)
Thank you

Tempees.com Team (Sonjoe, Kohut, Fuxxo)